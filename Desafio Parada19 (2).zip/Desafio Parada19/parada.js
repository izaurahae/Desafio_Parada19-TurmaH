function calcular(){
    let div = document.getElementById("resp");
    let peso = document.getElementById("peso").value;
    let altura = document.getElementById("altura").value;
    let imc = peso / (altura * altura);
    let text;
    
    

    if (imc < 18.5){
        text = `<h2>Você está abaixo de peso.</h2>`;
    } else if (imc >= 18.5 && imc < 25){
        text = `<h2> Você está com peso ideal.</h2>`;
    } else { 
        text = "<h2> Você está com sobrepeso.</h2>";
    }

    div.innerHTML = text; 
    div.style.textAlign="center";
  }
  